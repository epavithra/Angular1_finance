import { TestBed } from '@angular/core/testing';

import { SlmDetailsService } from './slm-details.service';

describe('SlmDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SlmDetailsService = TestBed.get(SlmDetailsService);
    expect(service).toBeTruthy();
  });
});
