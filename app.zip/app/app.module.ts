import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExecutiveSummaryComponent } from './executive-summary/executive-summary.component';
import { ProjectInfoComponent } from './project-info/project-info.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { FcproComponent } from './fcpro/fcpro.component';
import { FcskuComponent } from './fcsku/fcsku.component';
import { CountImpactComponent } from './count-impact/count-impact.component';
import { HealthComponent } from './health/health.component';
import { AssessmentComponent } from './assessment/assessment.component';
import { SlmDetailsService } from './slm-details.service';
import { RiskAssesmentServiceService } from './risk-assessment-service.service';
import { CountImpactService } from './count-impact.service';
import { HttpClientModule } from '@angular/common/http';
import { HighchartsChartComponent } from 'highcharts-angular';
// Import angular-fusioncharts
import { FusionChartsModule } from "angular-fusioncharts";

// Import FusionCharts library and chart modules
import * as FusionCharts from "fusioncharts";
import * as Charts from "fusioncharts/fusioncharts.charts";
import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import * as fusionchartsPowercharts from "fusioncharts/fusioncharts.powercharts";

// Pass the fusioncharts library and chart modules
FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme,fusionchartsPowercharts);



@NgModule({
  declarations: [
    AppComponent,
    ExecutiveSummaryComponent,
    ProjectInfoComponent,
    PagenotfoundComponent,
    FcproComponent,
    FcskuComponent,
    CountImpactComponent,
    HealthComponent,
    AssessmentComponent,
    HighchartsChartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule ,
    HttpClientModule,
    FusionChartsModule 
  ],
  providers: [SlmDetailsService,RiskAssesmentServiceService,CountImpactService],
  bootstrap: [AppComponent]
})
export class AppModule { }
