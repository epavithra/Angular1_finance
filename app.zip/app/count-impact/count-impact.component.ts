import { Component, OnInit } from '@angular/core';
import { CountImpactService } from '../count-impact.service';

@Component({
  selector: 'app-count-impact',
  templateUrl: './count-impact.component.html',
  styleUrls: ['./count-impact.component.css']
})
export class CountImpactComponent implements OnInit {

  public table1=[];
  public table2=[];

  constructor(private _count_impact_serv:CountImpactService) { }

  ngOnInit() {
    this.table1 = this._count_impact_serv.get_tab1_value();
    this.table2 = this._count_impact_serv.get_tab2_value();

  }

}
