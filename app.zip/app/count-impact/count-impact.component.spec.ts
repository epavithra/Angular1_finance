import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountImpactComponent } from './count-impact.component';

describe('CountImpactComponent', () => {
  let component: CountImpactComponent;
  let fixture: ComponentFixture<CountImpactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountImpactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountImpactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
