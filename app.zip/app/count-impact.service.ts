import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CountImpactService {

  constructor() { }

  get_tab1_value(){
    return [
      {"sku_type":"FG Case","c_version":109,"c_trade":102,"p_version":3,"p_trade":1},
      {"sku_type":"FG Pallet","c_version":26,"c_trade":25,"p_version":0,"p_trade":1},
      {"sku_type":"FG Display","c_version":19,"c_trade":18,"p_version":1,"p_trade":0},
      {"sku_type":"WIP/NFS","c_version":12,"c_trade":0,"p_version":1,"p_trade":1}
    ]
  }

  get_tab2_value(){
    return[
      {"product_code":"10001111100","rollover_indicator":"L","not_for_sale_indicator":"No","group":"048"},
      {"product_code":"10001111101","rollover_indicator":"R","not_for_sale_indicator":"Yes","group":"220"},
      {"product_code":"10001111102","rollover_indicator":"R","not_for_sale_indicator":"Yes","group":"048"},
      {"product_code":"10001111103","rollover_indicator":"L","not_for_sale_indicator":"No","group":"058"},
      {"product_code":"10001111104","rollover_indicator":"R","not_for_sale_indicator":"Yes","group":"048"}
    ]
  }
}

