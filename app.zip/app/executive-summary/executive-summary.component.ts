import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SlmDetailsService } from '../slm-details.service';

@Component({
  selector: 'app-executive-summary',
  templateUrl: './executive-summary.component.html',
  styleUrls: ['./executive-summary.component.css']
})
export class ExecutiveSummaryComponent implements OnInit {
  public Lists;
  constructor(private _slmdetailsservice:SlmDetailsService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.Lists=this._slmdetailsservice.getDetails();
  }

}
