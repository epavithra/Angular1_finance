import { Component, OnInit,NgZone } from '@angular/core';

const data = {
  chart: {
    /* caption: "Financial Contribution - SKU", */
    //primary axis
    /* yaxisname: "USD", */
    pYAxisMinValue:"0",
    pYAxisMaxValue:"30",
    numberSuffix:" k",
    numdivlines: "5",
    //secoundary axis
    /* syaxisname: "Percentage",     */
    sYAxisMaxValue: "51",
    sYAxisMinValue:"45",     
    //x axis
    xaxisname:"Material",
    theme: "fusion",
    drawcrossline: "1",
    divlinealpha: "20",//crosslines
    //legends
    showLegend:"1",
    legendPosition:"bottom",
    interactiveLegend: "0",
    drawCustomLegend:"1",
    legendIconSides: "4",
    //anchors
    drawAnchors:"1",
    labelFontColor:"#03a1fc",
  },
  categories: [
    {
      category: [
        {
          label: "101111100",
          //baseFontColor: "#0066cc"
         // outCnvBaseFontColor:"blue"
        },
        {
          label: "102222201"
        },
        {
          label: "103333301"
        }
      ]
    }
  ],
  dataset: [
    {
      dataset: [
        {
          seriesname: "Base Volume",
          color:"#a31aff",
          data: [
            {
              value: "13",
              color:"#a31aff"          
            },
            {
              value: "2",
              color:"#a31aff"
            },
            {
              value:"4",
              color:"#a31aff"
            }
          ]
        },
        {
          seriesname: "Incremental Volume",
          color:"#000080",
          data: [
            {
              value: "17",
              color:"#000080"
            },
            {
              value: "15",
              color:"#000080"
            },
            {
              value:"20",
              color:"#000080"
            }
          ]
        }
      ],
    }
  ],
   lineset: [
    {
      seriesname:"Est.VCM > Threshold",
      anchorBgColor:"#33ff33",
      color:"#33ff33",
      parentyaxis: "S",
      anchorBorderThickness: "2",
       data: [
        {          
          value: "47.8",
          anchorBorderColor:"#33ff33",
          color:"#33ff33",
          anchorBgColor:"#33ff33",
          anchorBorderThickness: "2"
        },
        {
          value: "45.5",
          anchorBorderColor:"#ffa31a",
          color:"#ffa31a",
          anchorBgColor: "#ffa31a"
        },
        {
          value:"48",
          anchorBorderColor:"#33ff33",
          color:"#33ff33",
          anchorBgColor: "#33ff33"
        }
      ]            
    }
  ]  ,
  //Trendlines for straight line
  trendlines: [   
        { 
          seriesname:"Platform Avg.VCM",
          showLegend:"1",
          legendIconScale:"5",
          legendIconBgColor: "#ff0000",
          legendIconSides: "5",
          drawCustomLegend:"1",  
          parentyaxis: "S",       
      line: [        
        {
          startvalue: "13",
          endvalue: "",
          color: "#29C3BE",
          displayvalue: "47.5%",
          valueonright: "1",
          thickness: "2"
        }
      ]
    },
    {
      line: [
        {
          startvalue: "10",
          endvalue: "",
          color: "#cc0099",
          displayvalue: "47.0%",
          valueonright: "1",
          thickness: "2"
        }
      ]
    },
  ],  
  };


@Component({
  selector: 'app-fcsku',
  templateUrl: './fcsku.component.html',
  styleUrls: ['./fcsku.component.css']
})
export class FcskuComponent {
  width = "600";
  height = "400";
  type = "msstackedcolumn2dlinedy";
  dataFormat = "json";
  dataSource = data;

  
}
