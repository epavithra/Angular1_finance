import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FcskuComponent } from './fcsku.component';

describe('FcskuComponent', () => {
  let component: FcskuComponent;
  let fixture: ComponentFixture<FcskuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FcskuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FcskuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
