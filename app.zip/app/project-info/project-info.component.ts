import { Component, OnInit } from '@angular/core';
import { SlmDetailsService } from '../slm-details.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-project-info',
  templateUrl: './project-info.component.html',
  styleUrls: ['./project-info.component.css']
})
export class ProjectInfoComponent implements OnInit {
  public Lists;
  constructor(private _slmdetailsservice:SlmDetailsService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.Lists=this._slmdetailsservice.getDetails();
  }

}
