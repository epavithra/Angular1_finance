import { TestBed } from '@angular/core/testing';

import { CountImpactService } from './count-impact.service';

describe('CountImpactService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CountImpactService = TestBed.get(CountImpactService);
    expect(service).toBeTruthy();
  });
});
