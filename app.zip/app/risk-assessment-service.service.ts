import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RiskAssesmentServiceService {

  constructor() { }

  get_details(){
    return {"date":"October 1,2018","accessor_name":"Jack Odell","date_stamp":"Dec 23,2018"}
  }
}

