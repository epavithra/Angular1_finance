import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExecutiveSummaryComponent } from './executive-summary/executive-summary.component';
import { ProjectInfoComponent } from './project-info/project-info.component';
import { FcproComponent } from './fcpro/fcpro.component';
import { FcskuComponent } from './fcsku/fcsku.component';
import { HealthComponent } from './health/health.component';
import { AssessmentComponent } from './assessment/assessment.component';
import { CountImpactComponent } from './count-impact/count-impact.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';


const routes: Routes = [{path:'',redirectTo:'/exe', pathMatch:'full'},
{path:'exe',component:ExecutiveSummaryComponent},
{path:'pro',component:ProjectInfoComponent,
children:[
{path:'',redirectTo:'/pro/fcpro',pathMatch:'full'},  
{path:'fcpro',component:FcproComponent},
{path:'fcsku',component:FcskuComponent},
{path:'impact',component:CountImpactComponent},
{path:'health',component:HealthComponent},
{path:'assessment',component:AssessmentComponent}]},
{ path: '**', component:PagenotfoundComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
