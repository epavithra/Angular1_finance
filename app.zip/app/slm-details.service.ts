import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SlmDetailsService {

  constructor() { }
  getDetails()
  {
    return{"id":"10000059","source":"IMF","steward":"Jake Odell","budget":"2019","platform":"Cottonelle",
    "region":"USA","stage":"BFC"}
  }
}
