import { Component, OnInit } from '@angular/core';
import { RiskAssesmentServiceService } from '../risk-assessment-service.service';

@Component({
  selector: 'app-assessment',
  templateUrl: './assessment.component.html',
  styleUrls: ['./assessment.component.css']
})
export class AssessmentComponent implements OnInit {
  public detail;

  constructor(private risk_service:RiskAssesmentServiceService) { }

  ngOnInit() {
    this.detail=this.risk_service.get_details();
  }

}
