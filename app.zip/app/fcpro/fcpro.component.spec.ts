import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FcproComponent } from './fcpro.component';

describe('FcproComponent', () => {
  let component: FcproComponent;
  let fixture: ComponentFixture<FcproComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FcproComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FcproComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
