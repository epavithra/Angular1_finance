import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-fcpro',
  templateUrl: './fcpro.component.html',
  styleUrls: ['./fcpro.component.css']
})
export class FcproComponent {
   width = 600;
   height = 400;
   type = "waterfall2d";
   dataFormat = "json";
   dataSource = data;
}
const data = {
   chart: {
     caption: "Financial Contribution - Project",
     numbersuffix: " k",
     pyaxisname: "USD",
     syaxisname: "Percentage",
     syaxismaxvalue: "51",
     syaxisminvalue:"45",
     yaxismaxvalue:"12",
     numdivlines: "5",
     /* sumlabel: "Total {br} Profit", */
     showvalues: "0",
     theme: "fusion",
    /*  plottooltext: "$label is <b>$datavalue</b>" */
   },
   data: [

     {
       label: "RollOver SKUs",
       value: "5"
     },
     {
       label: "Incremental SKUs",
       value: "4.5"
     }
     
   ],
   trendlines: [
      {
    line: [
      {
        startvalue: "4.8",
        endvalue: "",
        color: "#4080bf",
        displayvalue: "47.5%",
        valueonright: "1",
        thickness: "2"
      }
    ]
  },
  {
    line: [
      {
        startvalue: "4",
        endvalue: "",
        color: "#cc0099",
        displayvalue: "47.0%",
        valueonright: "1",
        thickness: "2"
      }
    ]
  },
],
 };
 


 





